import os
from flask import Flask, request, redirect, url_for, render_template_string, flash
from werkzeug.security import generate_password_hash, check_password_hash
import psycopg
from psycopg.rows import dict_row

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me")

DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is required")

def db():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)

def init_db():
    with db() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS users (
          id BIGSERIAL PRIMARY KEY,
          email TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('organization','admin')),
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE TABLE IF NOT EXISTS organizations (
          id BIGSERIAL PRIMARY KEY,
          user_id BIGINT UNIQUE REFERENCES users(id) ON DELETE SET NULL,
          name TEXT NOT NULL,
          organization_type TEXT NOT NULL,
          country TEXT,
          city TEXT,
          website TEXT,
          social_url TEXT,
          description TEXT,
          verification_status TEXT NOT NULL DEFAULT 'pending'
            CHECK(verification_status IN ('pending','verified','rejected')),
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE TABLE IF NOT EXISTS opportunities (
          id BIGSERIAL PRIMARY KEY,
          organization_id BIGINT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          sport TEXT NOT NULL,
          opportunity_type TEXT NOT NULL,
          country TEXT,
          city TEXT,
          age_category TEXT,
          gender_category TEXT,
          description TEXT NOT NULL,
          requirements TEXT,
          application_url TEXT,
          contact_email TEXT,
          deadline DATE,
          start_date DATE,
          cost_amount NUMERIC(12,2) DEFAULT 0,
          currency TEXT DEFAULT 'TZS',
          verification_status TEXT NOT NULL DEFAULT 'pending'
            CHECK(verification_status IN ('pending','verified','rejected','expired')),
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_opps_sport ON opportunities(sport);
        CREATE INDEX IF NOT EXISTS idx_opps_status ON opportunities(verification_status);
        """)
        c.commit()

init_db()

CSS = """body{font-family:system-ui,Arial;margin:0;background:#f7f9fc;color:#101828}.wrap{width:min(960px,92%);margin:40px auto}.brand{font-size:26px;font-weight:900;letter-spacing:.08em}.brand span{color:#155eef}.card{background:#fff;border:1px solid #e4e7ec;border-radius:18px;padding:26px;margin:18px 0}h1{font-size:38px;line-height:1.05}label{display:block;font-weight:700;margin:12px 0 6px}input,select,textarea{width:100%;box-sizing:border-box;padding:12px;border:1px solid #d0d5dd;border-radius:9px;font:inherit}textarea{min-height:120px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.full{grid-column:1/-1}button{border:0;border-radius:9px;padding:12px 17px;background:#155eef;color:#fff;font-weight:800;cursor:pointer}.muted{color:#667085}.notice{padding:12px;border-radius:10px;background:#ecfdf3;color:#027a48;margin:12px 0}.opp{border-top:1px solid #eaecf0;padding:18px 0}.small{font-size:13px;color:#667085}@media(max-width:700px){.grid{grid-template-columns:1fr}.full{grid-column:auto}}"""

def page(body, title="KICKNEXA"):
    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{CSS}</style></head><body><div class="wrap"><div class="brand">KICK<span>NEXA</span></div>{body}</div></body></html>"""

@app.get("/")
def home():
    return redirect(url_for("opportunities"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        f=request.form
        try:
            with db() as c:
                pw=generate_password_hash(f["password"])
                u=c.execute("INSERT INTO users(email,password_hash,role) VALUES(%s,%s,'organization') RETURNING id",
                            (f["email"].strip().lower(),pw)).fetchone()
                c.execute("""INSERT INTO organizations(user_id,name,organization_type,country,city,website,social_url,description)
                             VALUES(%s,%s,%s,%s,%s,%s,%s,%s)""",
                          (u["id"],f["name"],f["organization_type"],f.get("country"),f.get("city"),f.get("website"),f.get("social_url"),f.get("description")))
                c.commit()
            return page("<div class='card'><h1>Registration submitted</h1><p>Your organization account has been created and is awaiting verification.</p><a href='/post'>Post an opportunity</a></div>")
        except Exception:
            return page("<div class='card'><h1>Registration failed</h1><p>That email may already be registered or the submitted data is invalid.</p></div>")
    return page("""<div class="card"><h1>Register your organization</h1><p class="muted">Organizations are reviewed before they can be presented as verified.</p>
<form method="post"><div class="grid">
<div><label>Organization name<input required name="name"></label></div>
<div><label>Type<select name="organization_type"><option>Academy</option><option>Club</option><option>Coach</option><option>Tournament Organizer</option><option>Sports Organization</option><option>Other</option></select></label></div>
<div><label>Email<input required type="email" name="email"></label></div><div><label>Password<input required type="password" name="password" minlength="8"></label></div>
<div><label>Country<input name="country" value="Tanzania"></label></div><div><label>City<input name="city"></label></div>
<div><label>Website<input type="url" name="website"></label></div><div><label>Social profile<input name="social_url"></label></div>
<div class="full"><label>Description<textarea name="description"></textarea></label></div>
</div><button>Register</button></form></div>""","Register | KICKNEXA")

@app.route("/post", methods=["GET","POST"])
def post():
    if request.method == "POST":
        f=request.form
        with db() as c:
            # MVP: organization ID is used to identify the registered organization.
            org=c.execute("SELECT id FROM organizations WHERE id=%s",(f["organization_id"],)).fetchone()
            if not org:
                return page("<div class='card'><h1>Organization not found</h1><p>Check the organization ID.</p></div>")
            c.execute("""INSERT INTO opportunities
              (organization_id,title,sport,opportunity_type,country,city,age_category,gender_category,description,requirements,application_url,contact_email,deadline,start_date,cost_amount,currency)
              VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
              (f["organization_id"],f["title"],f["sport"],f["opportunity_type"],f.get("country"),f.get("city"),f.get("age_category"),f.get("gender_category"),
               f["description"],f.get("requirements"),f.get("application_url"),f.get("contact_email"),f.get("deadline") or None,f.get("start_date") or None,
               f.get("cost_amount") or 0,f.get("currency") or "TZS"))
            c.commit()
        return page("<div class='card'><h1>Opportunity submitted</h1><p>It is pending verification. Only verified opportunities should be promoted publicly.</p><a href='/opportunities'>View opportunities</a></div>")
    return page("""<div class="card"><h1>Post a sports opportunity</h1><form method="post"><div class="grid">
<div><label>Organization ID<input required type="number" name="organization_id"></label></div><div><label>Title<input required name="title"></label></div>
<div><label>Sport<input required name="sport"></label></div><div><label>Type<select name="opportunity_type"><option>Trial</option><option>Scholarship</option><option>Competition</option><option>Training Camp</option><option>Academy</option><option>Sponsorship</option><option>Other</option></select></label></div>
<div><label>Country<input name="country" value="Tanzania"></label></div><div><label>City<input name="city"></label></div>
<div><label>Age category<input name="age_category"></label></div><div><label>Gender/category<input name="gender_category"></label></div>
<div><label>Deadline<input type="date" name="deadline"></label></div><div><label>Start date<input type="date" name="start_date"></label></div>
<div class="full"><label>Description<textarea required name="description"></textarea></label></div><div class="full"><label>Requirements<textarea name="requirements"></textarea></label></div>
<div><label>Application URL<input type="url" name="application_url"></label></div><div><label>Contact email<input type="email" name="contact_email"></label></div>
</div><button>Submit opportunity</button></form></div>""","Post Opportunity | KICKNEXA")

@app.get("/opportunities")
def opportunities():
    with db() as c:
        rows=c.execute("""SELECT o.*, org.name org_name FROM opportunities o
                          JOIN organizations org ON org.id=o.organization_id
                          WHERE o.verification_status='verified'
                          ORDER BY o.created_at DESC""").fetchall()
    items="".join(f"<div class='opp'><h2>{r['title']}</h2><b>{r['sport']}</b> · {r['opportunity_type']}<p>{r['description']}</p><div class='small'>{r['org_name']} · {r['city'] or ''} {r['country'] or ''}</div></div>" for r in rows)
    return page(f"<div class='card'><h1>Verified Opportunities</h1>{items or '<p>No verified opportunities yet.</p>'}</div>","Opportunities | KICKNEXA")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT","10000")))
