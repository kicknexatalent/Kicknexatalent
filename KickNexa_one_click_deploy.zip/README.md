# KICKNEXA One-Click Deployment Starter

Recommended architecture:
- Web app: Render
- Database/Auth/storage: Supabase PostgreSQL (or another managed PostgreSQL provider)
- Source: GitHub

Render can deploy Python web services from GitHub and supports a `render.yaml` Blueprint. Its free web service is suitable for testing/hobby use but has spin-down and usage limitations; Render explicitly says free instances are not for production. Render's free Postgres also expires after 30 days, so this project deliberately expects an external/managed Postgres such as Supabase for the database. 

Supabase's free plan currently includes a Postgres database, Auth, storage and APIs, with usage limits and automatic pausing after inactivity. For production, upgrade when the project needs reliable uptime/backups/quotas.

## Fast deployment
1. Create a GitHub repository named `kicknexa`.
2. Upload these files.
3. Create a Supabase project and copy its Postgres connection string. For an IPv4-only backend, use Supabase's Session Pooler connection string.
4. In Render, choose New -> Blueprint and select the GitHub repo.
5. Set `DATABASE_URL` to the Supabase connection string.
6. Render will build with `pip install -r requirements.txt` and start with Gunicorn.
7. Open the generated Render URL.
8. Add a custom domain later.

## Current MVP
- Organization registration with password hashing
- Organization profile storage
- Opportunity submission
- Pending/verified opportunity status
- Public directory shows only verified opportunities

## Before public production
The `/post` route still uses an organization ID for the MVP. Replace this with authenticated organization sessions before real public use. Add CSRF protection, rate limiting, email verification, admin moderation, audit logs, privacy policy/consent, guardian consent for minors, file scanning, backups, and role-based access controls.

Do not put database passwords or SECRET_KEY into source control.
